<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Services\AttendanceService;
use App\Http\Requests\AttendanceRequest;
use App\Http\Requests\GetAttendanceRequest;
use Illuminate\Support\Carbon;

class AttendanceController extends Controller
{
  
     /**
     * Get all attendance list.
     */
    public function index(GetAttendanceRequest $request){
        
        //validate request data
        $validated = $request->validated(); 
        if($validated){
            $attendances = (new AttendanceService())->index($request);
            if(count($attendances) > 0){
                return response()->json([
                    'success' => true,
                    'message' => "Get attendance successfully",
                    'data' => $attendances
                ],200);
            } else {
                return response()->json([
                    'success' => false,
                    'message'=>"No attendance found"
                ],404);
            }
        }

    }

     /**
     * Store a attendance
     */
    public function store(AttendanceRequest $request){
        //validate request data
        $validated = $request->validated();
        if($validated){
            $data = (new AttendanceService())->store($request);
            if($data){
                return response()->json([
                    'success' => true,
                    'message' => "Attendance created successfully",
                    'data' => $data
                ],200);
            } else {
                return response()->json([
                    'success' => false,
                    'message'=>"Attendance not created"
                ],404);
            }
        }
    }


     /**
     * Get today attendance
     */
    public function todayAttendance(){
        $now = Carbon::now();
        dd($now);
        if($validated){
            $data = (new AttendanceService())->store($request);
            if($data){
                return response()->json([
                    'success' => true,
                    'message' => "Attendance created successfully",
                    'data' => $data
                ],200);
            } else {
                return response()->json([
                    'success' => false,
                    'message'=>"Attendance not created"
                ],404);
            }
        }
    }
}